// export const firebaseConfig = () => ({
//   apiKey: 'AIzaSyB4NgYHqc_YQS752DhctRA-SH_hNOtUNrM',
//   authDomain: 'guardiaotec-tms-prototype.firebaseapp.com',
//   projectId: 'guardiaotec-tms-prototype',
//   storageBucket: 'guardiaotec-tms-prototype.appspot.com',
//   messagingSenderId: '332551291469',
//   appId: '1:332551291469:web:658590faa07384158dd204',
// });
export const firebaseConfig = () => ({
  apiKey: 'AIzaSyDFJJzKedMPkPMsbBaDwuVyrhsGGxf0L6M',
  authDomain: 'guardiaotec-tms.firebaseapp.com',
  projectId: 'guardiaotec-tms',
  storageBucket: 'guardiaotec-tms.appspot.com',
  messagingSenderId: '1030687051805',
  appId: '1:1030687051805:web:1d3ca6eeb5103a7faeb6f4',
});
