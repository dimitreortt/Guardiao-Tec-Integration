export const serverUrl = () => {
  return 'https://us-central1-guardiaotec-tms.cloudfunctions.net/createUser';
};
